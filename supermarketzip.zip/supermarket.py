from datetime import datetime
name=input("Enter your name: \n")
#LIST OF ITEMS AVAILABLE 
list='''
Rice- ₹20/kg
Sugar- ₹30/kg
Salt- ₹20/kg
Oil- ₹80/liter
Paneer- ₹110/kg
Maggi- ₹50/kg
Complan- ₹90/kg
Colgate- ₹80/kg
'''
#DECLARATION
price=0
price_list=[]
total_price=0
final_price=0
item_list=[]
quant_list=[]
plist=[]
items={ 'Rice':20,
        'Sugar':30,
        'Salt':20,
        'Oil':80,
        'Paneer':110,
        'Maggi':50,
        'Complan':90,
        'Colgate':80}
option=int(input("Enter 1 to get list of items available: "))
if option==1:
    print(list)
for i in range(len(items)):
    inp1=int(input("If you want to buy press 1 else press 2: "))
    if inp1==2:
         break
    if inp1==1:
        item=input("Enter your items: ")
        qt=int(input("Enter your quantity: "))
        if item in items.keys():
            price=items[item]*qt  
            price_list.append((item,qt,items,price))
            total_price+=price
            item_list.append(item)
            quant_list.append(item)
            plist.append(price)
            gst=(total_price*5)/100
            final_price=gst+total_price
        else:
            print("Sorry! The item you entered is not available")

    else:
        print("Wrong Choice")
    inp2=input("Can I bill the items? yes or no ")
    if inp2=='yes':
        pass
        if final_price!=0:
            print(25*"=","Happy Supermarket",25*"=")
            print("Name",name,30*"","Date",datetime.now())
            print(75*'-')
            print("sno",8*" ",'items',8*" ",'quantity',3*" ",'price',)
            for i in range(len(price_list)):
                print(i,8*" ",item_list[i],8*" ",quant_list[i],3*" ",plist[i])
            print(75*"-")
            print(50*" ",'Total amount: ','Rs.',total_price)
            print(' GST amount: ',50*" ",'Rs.',gst)
            print(75*'-')
            print(50*" ",'Final price','Rs.',final_price)
            print(75*'-')
            print(20*" ","Thanks for visiting! ")
            print(75*'-')