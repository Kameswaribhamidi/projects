'''
select word and ask player to guess a letter
check if letter is present in ans word
    if not present lose a life
        check if all lives are lost
            if yes then-> GAME OVER
        else player gets another chance
if the word is guessed correctly-> PLAYER WINS

'''
import random
logo = ''' 
 _                                             
| |                                            
| |__   __ _ _ __   __ _ _ __ ___   __ _ _ __  
| '_ \ / _` | '_ \ / _` | '_ ` _ \ / _` | '_ \ 
| | | | (_| | | | | (_| | | | | | | (_| | | | |
|_| |_|\__,_|_| |_|\__, |_| |_| |_|\__,_|_| |_|
                    __/ |                      
                   |___/    '''
stages = [ '''
  +---+
  |   |
  O   |
 /|\  |
 / \  |
      |
=========
''', '''
  +---+
  |   |
  O   |
 /|\  |
 /    |
      |
=========
''', '''
  +---+
  |   |
  O   |
 /|\  |
      |
      |
=========
''', '''
  +---+
  |   |
  O   |
 /|   |
      |
      |
=========
''', '''
  +---+
  |   |
  O   |
  |   |
      |
      |
=========
''','''
  +---+
  |   |
  O   |
      |
      |
      |
=========
''','''
  +---+
  |   |
      |
      |
      |
      |
=========
''']
words_list=["hello","good","bad","morning","afternoon"]
word=random.choice(words_list).lower()
print(word)
len=len(word)
life=6
end=False
guess_list=[]
for i in range(len):
    guess_list+='_'
print(logo)
print("*"*15,"WELCOME TO HANGMAN GAME","*"*15)
print('\n')        

while not end:
    ch=input("Guess a letter for the hidden word: ").lower()
    for i in range(len):
        k=word[i]
        if k==ch:
            guess_list[i]=ch
        
    if ch not in word:  
        print(f"Your guess({ch}) is not in the word.Try Again!")
        print("You've {life} chances left.")
        print(stages[life])
        life-=1
        if life==0:
            end=True
            print("YOU LOSE.")
        
        
    print(f"{''.join(guess_list)}")
    if '_' not in guess_list:
        end=True
        print("YOU WIN")

