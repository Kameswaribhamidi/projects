'''
select word and ask player to guess a letter
check if letter is present in ans word
    if not present lose a life
        check if all lives are lost
            if yes then-> GAME OVER
        else player gets another chance
if the word is guessed correctly-> PLAYER WINS

'''
import random
logo = ''' 
 _                                             
| |                                            
| |__   __ _ _ __   __ _ _ __ ___   __ _ _ __  
| '_ \ / _` | '_ \ / _` | '_ ` _ \ / _` | '_ \ 
| | | | (_| | | | | (_| | | | | | | (_| | | | |
|_| |_|\__,_|_| |_|\__, |_| |_| |_|\__,_|_| |_|
                    __/ |                      
                   |___/    '''
stages = [ '''
  +---+
  |   |
  O   |
 /|\  |
 / \  |
      |
=========
''', '''
  +---+
  |   |
  O   |
 /|\  |
 /    |
      |
=========
''', '''
  +---+
  |   |
  O   |
 /|\  |
      |
      |
=========
''', '''
  +---+
  |   |
  O   |
 /|   |
      |
      |
=========
''', '''
  +---+
  |   |
  O   |
  |   |
      |
      |
=========
''','''
  +---+
  |   |
  O   |
      |
      |
      |
=========
''','''
  +---+
  |   |
      |
      |
      |
      |
=========
''']
words_list=['Head','Face','Hair','Ear','Neck','Forehead','Beard','Eye','Nose','Mouth',
'Chin','Shoulder','Elbow','Arm','Chest','Armpit','Forearm','Wrist','Back','Navel','Toes',
'Ankle','Toenail','Waist','Abdomen','Hip','Leg','Thigh','Knee','Foot','Hand','Thumb']
word=random.choice(words_list).lower()
print(word)
len=len(word)
life=6
end=False
guess_list=[]
for i in range(len):
    guess_list+='_'
print(logo)
print("*"*15,"WELCOME TO HANGMAN GAME","*"*15)
print('\n')        
print("Hint: The answer word is a part of human body!")
while not end:
    ch=input("Guess a letter for the hidden word: ").lower()
    for i in range(len):
        k=word[i]
        if k==ch:
            guess_list[i]=ch
        
    if ch not in word:  
        print()
        print(f"Your guess{ch} is not in the word.Try Again!")
        print(stages[life])
        life-=1
        print(f"You've {life} chances left.")
        if life==0:
            end=True
            print()
            print("YOU LOSE.")
        
    print()   
    print(f"{'  '.join(guess_list)}")
    print()
    if '_' not in guess_list:
        end=True
        print()
        print("YOU WIN")

